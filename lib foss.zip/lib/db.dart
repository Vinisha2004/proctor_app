import 'package:foss/main.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DatabaseService {
  Future fetchStudentData({required userId}) async {
    try {
      var response = await sb.from('students').select();
      print(response);
    } catch (e) {
      print(e.toString());
    }
  }

  Future createStudentData({
    required String fname,
    required String lname,
    required String regNo,
    required String rollNo,
    required int phone,
  }) async {
    try {
      PostgrestResponse? response = await sb.from('students').insert({
        'uid': sb.auth.currentUser!.id,
        'first_name': fname,
        'last_name': lname,
        'register_number': regNo,
        'roll_number': rollNo,
        'phone_number': phone
      });
      print(response);
    } catch (e) {
      print(e.toString());
    }
  }
}
